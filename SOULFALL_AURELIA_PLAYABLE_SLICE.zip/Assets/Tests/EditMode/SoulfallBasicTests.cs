#if UNITY_EDITOR
using NUnit.Framework;
using Soulfall.Corruption;
using Soulfall.Souls;
using UnityEngine;

namespace Soulfall.Tests
{
    public class SoulfallBasicTests
    {
        [Test]
        public void Corruption_Clamps_To_100()
        {
            var go = new GameObject();
            var c = go.AddComponent<CorruptionSystem>();
            c.Change(150);
            Assert.AreEqual(100, c.value);
            Assert.AreEqual(CorruptionStage.Fallen, c.Stage);
            Object.DestroyImmediate(go);
        }

        [Test]
        public void SoulPower_Increases()
        {
            var go = new GameObject();
            var s = go.AddComponent<SoulPowerSystem>();
            s.AbsorbSoul(25);
            Assert.AreEqual(1, s.absorbedSouls);
            Assert.AreEqual(25, s.soulPower);
            Object.DestroyImmediate(go);
        }
    }
}
#endif

# Required Art Assets

Player: Warrior, Assassin, Mage, Ranger, Necromancer; each needs base body, 3 armor tiers, 2–3 skins, weapon set, rig, locomotion, attacks, skills, hit/death, emotes.

Aurelia: Ember Gate kit, ruined cathedral kit, shard fields, Sunken Gardens, Warden Citadel, vegetation, props, decals, sky/fog profiles.

Enemies: Hollow Hound + variants, cultist, shard golem, fallen knight, soul wraith, Aurelia Warden boss.

Corruption variants: glowing eyes, demonic markings, transformed armor overlays, Fallen Form silhouette/VFX.

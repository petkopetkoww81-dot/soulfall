using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace Soulfall.Player
{
    [RequireComponent(typeof(CharacterController))]
    public class ThirdPersonMobileMotor : MonoBehaviour
    {
        public float moveSpeed = 5.6f;
        public float sprintSpeed = 7.5f;
        public float rotationSpeed = 12f;
        public float gravity = -24f;
        public float dodgeSpeed = 18f;
        public float dodgeDuration = .20f;
        public float dodgeCooldown = .75f;
        public Transform cameraTransform;

        CharacterController controller;
        Vector2 moveInput;
        float verticalVelocity;
        float dodgeUntil;
        float dodgeReadyAt;
        Vector3 dodgeDirection;
        bool sprinting;

        void Awake() => controller = GetComponent<CharacterController>();

        public void SetMove(Vector2 value) => moveInput = Vector2.ClampMagnitude(value, 1f);
        public void SetSprint(bool value) => sprinting = value;

        public void Dodge()
        {
            if (Time.time < dodgeReadyAt || moveInput.sqrMagnitude < .01f) return;
            dodgeReadyAt = Time.time + dodgeCooldown;
            dodgeUntil = Time.time + dodgeDuration;
            dodgeDirection = transform.forward;
        }

        void Update()
        {
            if (controller == null) return;

            if (Time.time < dodgeUntil)
            {
                controller.Move(dodgeDirection * dodgeSpeed * Time.deltaTime);
                ApplyGravity();
                return;
            }

            Vector3 forward = cameraTransform ? cameraTransform.forward : Vector3.forward;
            Vector3 right = cameraTransform ? cameraTransform.right : Vector3.right;
            forward.y = 0f; right.y = 0f;
            forward.Normalize(); right.Normalize();

            Vector3 dir = forward * moveInput.y + right * moveInput.x;
            if (dir.sqrMagnitude > .001f)
            {
                transform.rotation = Quaternion.Slerp(
                    transform.rotation,
                    Quaternion.LookRotation(dir),
                    rotationSpeed * Time.deltaTime
                );
            }

            float speed = sprinting ? sprintSpeed : moveSpeed;
            controller.Move(dir.normalized * speed * Time.deltaTime);
            ApplyGravity();
        }

        void ApplyGravity()
        {
            if (controller.isGrounded && verticalVelocity < 0) verticalVelocity = -2f;
            verticalVelocity += gravity * Time.deltaTime;
            controller.Move(Vector3.up * verticalVelocity * Time.deltaTime);
        }
    }
}

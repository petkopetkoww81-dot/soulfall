using UnityEngine;
namespace Soulfall.Bounty { public class BountyManager:MonoBehaviour{public bool active;public int tier,goldReward;public bool hunterPlayersCanTrack;public void Refresh(int corruption,int souls){active=corruption>=90;tier=corruption>=100?5:corruption>=90?3:0;if(souls>=100)tier=Mathf.Max(tier,4);goldReward=tier*1250;hunterPlayersCanTrack=active;} } }

using UnityEngine; using System.Collections.Generic;
namespace Soulfall.Inventory { public class InventorySystem:MonoBehaviour{public List<string> itemIds=new(); public void Add(string id){itemIds.Add(id);} public bool Has(string id)=>itemIds.Contains(id);} }

using UnityEngine;
using Soulfall.Inventory;

namespace Soulfall.Loot
{
    public class LootDropper : MonoBehaviour
    {
        public LootTable table;
        public InventorySystem playerInventory;

        public void GrantLoot()
        {
            if (table == null || playerInventory == null) return;
            foreach (var item in table.Roll())
                playerInventory.Add(item.itemId, item.amount);
        }
    }
}

using UnityEngine;
using System;
using System.Collections.Generic;

namespace Soulfall.Loot
{
    [Serializable]
    public class LootEntry
    {
        public string itemId;
        public int minAmount = 1;
        public int maxAmount = 1;
        [Range(0,1)] public float chance = 1f;
    }

    public class LootTable : MonoBehaviour
    {
        public List<LootEntry> entries = new();

        public List<(string itemId, int amount)> Roll()
        {
            var result = new List<(string, int)>();
            foreach (var e in entries)
            {
                if (UnityEngine.Random.value > e.chance) continue;
                int amount = UnityEngine.Random.Range(e.minAmount, e.maxAmount + 1);
                result.Add((e.itemId, amount));
            }
            return result;
        }
    }
}

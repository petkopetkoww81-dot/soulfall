using UnityEngine;
using Soulfall.Combat;
namespace Soulfall.Enemies {
 [RequireComponent(typeof(Damageable))]
 public class HollowHound:MonoBehaviour{
  public float aggroRange=14,attackRange=1.7f,moveSpeed=4.2f,damage=12,cooldown=1.25f; Transform target; float next;
  void Update(){if(!target){var p=GameObject.FindGameObjectWithTag("Player");if(p)target=p.transform;else return;} float d=Vector3.Distance(transform.position,target.position);if(d>aggroRange)return; if(d>attackRange){transform.position=Vector3.MoveTowards(transform.position,target.position,moveSpeed*Time.deltaTime);transform.LookAt(new Vector3(target.position.x,transform.position.y,target.position.z));}else if(Time.time>=next){next=Time.time+cooldown;var hp=target.GetComponent<Damageable>();if(hp)hp.TakeDamage(damage);} }
 }
}

using UnityEngine;
using UnityEngine.AI;
using Soulfall.Combat;

namespace Soulfall.Enemies
{
    [RequireComponent(typeof(NavMeshAgent))]
    public class EnemyMeleeController : MonoBehaviour
    {
        public Transform target;
        public float aggroRange = 14f;
        public float attackRange = 1.7f;
        public float damage = 12f;
        public float attackCooldown = 1.25f;

        NavMeshAgent agent;
        float nextAttack;

        void Awake() => agent = GetComponent<NavMeshAgent>();

        void Update()
        {
            if (target == null) return;
            float d = Vector3.Distance(transform.position, target.position);
            if (d > aggroRange) return;

            if (d > attackRange)
            {
                if (agent.isOnNavMesh) agent.SetDestination(target.position);
                return;
            }

            if (agent.isOnNavMesh) agent.ResetPath();
            if (Time.time < nextAttack) return;
            nextAttack = Time.time + attackCooldown;

            var hp = target.GetComponent<Damageable>();
            if (hp != null) hp.ApplyDamage(damage);
        }
    }
}

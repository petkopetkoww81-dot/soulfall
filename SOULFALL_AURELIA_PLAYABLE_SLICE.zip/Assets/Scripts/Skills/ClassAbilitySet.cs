using UnityEngine;
using System;
using Soulfall.Characters;
using Soulfall.Combat;

namespace Soulfall.Skills
{
    [Serializable]
    public struct AbilitySpec
    {
        public string id;
        public float damage;
        public float cooldown;
        public float range;
    }

    public class ClassAbilitySet : MonoBehaviour
    {
        public SoulfallClass classType;
        public AbilitySpec primary;
        public AbilitySpec skill1;
        public AbilitySpec skill2;
        public AbilitySpec skill3;
        public AbilitySpec ultimate;

        float[] readyAt = new float[5];

        public bool TryCast(int slot, Damageable target)
        {
            if (slot < 0 || slot >= readyAt.Length || target == null) return false;
            if (Time.time < readyAt[slot]) return false;

            AbilitySpec spec = slot switch
            {
                0 => primary,
                1 => skill1,
                2 => skill2,
                3 => skill3,
                _ => ultimate
            };

            readyAt[slot] = Time.time + Mathf.Max(0.05f, spec.cooldown);
            target.ApplyDamage(Mathf.Max(0f, spec.damage));
            return true;
        }
    }
}

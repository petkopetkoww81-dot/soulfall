using UnityEngine;
using Soulfall.Characters;

namespace Soulfall.Skills
{
    public class ClassAbilityPresets : MonoBehaviour
    {
        public ClassAbilitySet abilities;

        public void Apply(SoulfallClass type)
        {
            if (abilities == null) return;
            abilities.classType = type;

            switch(type)
            {
                case SoulfallClass.Warrior:
                    abilities.primary = A("warrior_slash",22,.48f,2.2f);
                    abilities.skill1 = A("shield_charge",45,6,4);
                    abilities.skill2 = A("ground_breaker",70,9,3);
                    abilities.skill3 = A("iron_guard",55,12,2);
                    abilities.ultimate = A("warden_execution",180,35,3);
                    break;
                case SoulfallClass.Assassin:
                    abilities.primary = A("twin_cut",20,.4f,2);
                    abilities.skill1 = A("shadow_dash",52,5,5);
                    abilities.skill2 = A("veil_strike",78,9,2);
                    abilities.skill3 = A("death_mark",60,12,8);
                    abilities.ultimate = A("nightfall",195,35,4);
                    break;
                case SoulfallClass.Mage:
                    abilities.primary = A("arc_bolt",18,.55f,10);
                    abilities.skill1 = A("ember_lance",58,5,11);
                    abilities.skill2 = A("frost_circle",62,8,5);
                    abilities.skill3 = A("rift_prison",50,12,8);
                    abilities.ultimate = A("starfall",205,38,12);
                    break;
                case SoulfallClass.Ranger:
                    abilities.primary = A("precision_shot",21,.5f,14);
                    abilities.skill1 = A("vault_shot",48,5,10);
                    abilities.skill2 = A("soul_trap",68,9,8);
                    abilities.skill3 = A("storm_volley",58,10,12);
                    abilities.ultimate = A("heartseeker",190,34,16);
                    break;
                case SoulfallClass.Necromancer:
                    abilities.primary = A("grave_bolt",19,.55f,10);
                    abilities.skill1 = A("soul_drain",50,6,8);
                    abilities.skill2 = A("bone_servant",62,10,7);
                    abilities.skill3 = A("king_curse",74,12,10);
                    abilities.ultimate = A("fallen_legion",210,40,10);
                    break;
            }
        }

        static AbilitySpec A(string id,float damage,float cooldown,float range) =>
            new AbilitySpec{id=id,damage=damage,cooldown=cooldown,range=range};
    }
}

using System;using System.Collections.Generic;
namespace Soulfall.Save { [Serializable]public class WorldSnapshot{public string characterName;public string classId;public int level,xp,gold,crystals,corruption,absorbedSouls,soulPower;public List<string> inventory=new();public List<string> worldFlags=new();public List<string> companions=new();public List<string> guildBosses=new();} }

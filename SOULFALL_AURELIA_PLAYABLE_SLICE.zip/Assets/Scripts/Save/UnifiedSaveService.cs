using UnityEngine;
using System.IO;

namespace Soulfall.Save
{
    public class UnifiedSaveService : MonoBehaviour
    {
        const string FileName = "soulfall_save.json";
        string PathName => Path.Combine(Application.persistentDataPath, FileName);

        public void Save(UnifiedSaveGame data)
        {
            File.WriteAllText(PathName, JsonUtility.ToJson(data, true));
        }

        public bool TryLoad(out UnifiedSaveGame data)
        {
            data = null;
            if (!File.Exists(PathName)) return false;
            data = JsonUtility.FromJson<UnifiedSaveGame>(File.ReadAllText(PathName));
            return data != null;
        }

        public void DeleteLocalSave()
        {
            if (File.Exists(PathName)) File.Delete(PathName);
        }
    }
}

using System;
using System.Collections.Generic;

namespace Soulfall.Save
{
    [Serializable]
    public class UnifiedSaveGame
    {
        public int schemaVersion = 1;
        public string characterName;
        public string classId;
        public int level = 1;
        public int xp;
        public int gold;
        public int crystals;
        public int corruption;
        public int soulPower;
        public int absorbedSouls;
        public string necromancyPath;
        public List<string> inventory = new();
        public List<string> worldFlags = new();
        public List<string> companions = new();
        public List<string> guildBosses = new();
    }
}

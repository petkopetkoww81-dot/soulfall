using UnityEngine;
namespace Soulfall.Save { public class LocalSaveService:MonoBehaviour{const string Key="SOULFALL_SAVE";public void Save(WorldSnapshot s){PlayerPrefs.SetString(Key,JsonUtility.ToJson(s));PlayerPrefs.Save();}public WorldSnapshot Load(){var j=PlayerPrefs.GetString(Key,"");return string.IsNullOrEmpty(j)?new WorldSnapshot():JsonUtility.FromJson<WorldSnapshot>(j);} } }

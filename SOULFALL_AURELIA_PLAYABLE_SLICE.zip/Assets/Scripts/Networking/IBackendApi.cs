using System.Threading.Tasks;
namespace Soulfall.Networking { public interface IBackendApi{Task<string> GetProfile(string userId);Task<bool> PutProfile(string userId,string json);Task<string> Matchmake(string queue);} }

using System;

namespace Soulfall.Networking
{
    [Serializable]
    public class BackendPlayerState
    {
        public string playerId;
        public string displayName;
        public string classId;
        public int level;
        public int corruption;
        public int soulPower;
    }

    [Serializable]
    public class MatchTicket
    {
        public string queueId;
        public string region;
        public int partySize;
    }
}

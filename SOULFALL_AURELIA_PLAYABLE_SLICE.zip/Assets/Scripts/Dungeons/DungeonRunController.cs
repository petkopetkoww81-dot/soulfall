using UnityEngine;
namespace Soulfall.Dungeons { public class DungeonRunController:MonoBehaviour{public int rooms=5,currentRoom;public bool complete;public void CompleteRoom(){if(complete)return;currentRoom++;if(currentRoom>=rooms)complete=true;} } }

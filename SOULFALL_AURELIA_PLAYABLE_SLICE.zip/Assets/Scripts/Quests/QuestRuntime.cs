using UnityEngine;
using System;
using System.Collections.Generic;

namespace Soulfall.Quests
{
    public enum ObjectiveType { Kill, Collect, Interact, Discover, Boss, Choice }

    [Serializable]
    public class QuestObjectiveState
    {
        public string id;
        public ObjectiveType type;
        public string targetId;
        public int required = 1;
        public int current;
        public bool Complete => current >= required;
    }

    public class QuestRuntime : MonoBehaviour
    {
        public string questId;
        public bool active;
        public bool completed;
        public List<QuestObjectiveState> objectives = new();

        public event Action<QuestRuntime> Changed;
        public event Action<QuestRuntime> Completed;

        public void StartQuest()
        {
            if (completed) return;
            active = true;
            Changed?.Invoke(this);
        }

        public void Progress(string targetId, int amount = 1)
        {
            if (!active || completed) return;

            foreach (var o in objectives)
            {
                if (!o.Complete && o.targetId == targetId)
                    o.current = Mathf.Min(o.required, o.current + Mathf.Max(0, amount));
            }

            if (objectives.Count > 0 && objectives.TrueForAll(x => x.Complete))
            {
                completed = true;
                active = false;
                Completed?.Invoke(this);
            }

            Changed?.Invoke(this);
        }
    }
}

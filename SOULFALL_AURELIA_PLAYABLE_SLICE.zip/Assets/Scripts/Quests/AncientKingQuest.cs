using UnityEngine;using Soulfall.WorldState;using Soulfall.Souls;using Soulfall.Corruption;using Soulfall.Companions;using Soulfall.Guilds;using Soulfall.Factions;
namespace Soulfall.Quests {
 public enum NecromancyAlignment{Neutral,Holy,Dark,Fallen}
 public class AncientKingQuest:MonoBehaviour{
  public SoulPowerSystem souls;public CorruptionSystem corruption;public CompanionSystem companions;public GuildSystem guild;public FactionReputation factions;public NecromancyAlignment alignment;public bool resolved;public string outcome;
  public void Release(){if(resolved)return;alignment=NecromancyAlignment.Holy;corruption.Change(-20);factions?.Change("Soulkeepers",300);Commit("release","king_soul_released");}
  public void Consume(){if(resolved)return;alignment=NecromancyAlignment.Dark;souls.AbsorbSoul(25);corruption.Change(30);factions?.Change("Ash Covenant",250);factions?.Change("Soulkeepers",-350);Commit("consume","king_soul_consumed");}
  public void Resurrect(){if(resolved)return;companions.Unlock("ancient_king");companions.Loyalty("ancient_king",20);corruption.Change(10);Commit("resurrect","king_resurrected");}
  public void GiveToGuild(){if(resolved)return;guild.reputation+=250;guild.UnlockBoss("soulbound_king");Commit("guild","king_soul_given_to_guild");}
  void Commit(string o,string flag){resolved=true;outcome=o;WorldStateManager.Instance?.Set(flag);WorldStateManager.Instance?.Set("ancient_king_outcome",o);}
  public void RefreshFallen(){if(corruption.value>=100&&alignment==NecromancyAlignment.Dark)alignment=NecromancyAlignment.Fallen;}
 }
}

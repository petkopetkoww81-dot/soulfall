using UnityEngine;
using System;
namespace Soulfall.Combat {
 public class Damageable:MonoBehaviour{
  public float maxHealth=100, health; public bool IsDead=>health<=0; public event Action<float> Damaged; public event Action Died;
  void Awake(){health=maxHealth;}
  public void TakeDamage(float amount){if(IsDead)return; health=Mathf.Max(0,health-Mathf.Max(0,amount)); Damaged?.Invoke(amount); if(IsDead)Died?.Invoke();}
 }
}

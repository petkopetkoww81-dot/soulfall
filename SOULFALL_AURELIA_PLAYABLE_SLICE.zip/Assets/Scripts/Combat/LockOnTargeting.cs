using UnityEngine;
namespace Soulfall.Combat {
 public class LockOnTargeting:MonoBehaviour{
  public float radius=15; public LayerMask targetMask; public Transform Current {get;private set;}
  public void Acquire(){float best=float.MaxValue; Transform t=null; foreach(var c in Physics.OverlapSphere(transform.position,radius,targetMask)){float d=(c.transform.position-transform.position).sqrMagnitude;if(d<best){best=d;t=c.transform;}} Current=t;}
  public void Clear()=>Current=null;
 }
}

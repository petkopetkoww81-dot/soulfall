using UnityEngine;
using System;
using System.Collections.Generic;

namespace Soulfall.Combat
{
    public class EncounterDirector : MonoBehaviour
    {
        public List<Damageable> hostiles = new();
        public bool encounterActive;
        public event Action EncounterCleared;

        public void Register(Damageable target)
        {
            if (target != null && !hostiles.Contains(target))
                hostiles.Add(target);
        }

        void Update()
        {
            if (!encounterActive) return;
            hostiles.RemoveAll(x => x == null || x.CurrentHealth <= 0);

            if (hostiles.Count == 0)
            {
                encounterActive = false;
                EncounterCleared?.Invoke();
            }
        }

        public void Begin() => encounterActive = true;
    }
}

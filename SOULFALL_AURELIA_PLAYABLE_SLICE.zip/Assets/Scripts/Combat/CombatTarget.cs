using UnityEngine;

namespace Soulfall.Combat
{
    public class CombatTarget : MonoBehaviour
    {
        public Damageable damageable;
        public Transform aimPoint;

        void Reset()
        {
            damageable = GetComponent<Damageable>();
            aimPoint = transform;
        }
    }
}

using UnityEngine;
using Soulfall.Souls;
using Soulfall.Corruption;
namespace Soulfall.Combat {
 public class PlayerCombat:MonoBehaviour{
  public Transform attackOrigin; public float range=2.3f; public LayerMask hitMask; public float basicDamage=22; public float cooldown=.48f; float next;
  public SoulPowerSystem souls; public CorruptionSystem corruption;
  public void BasicAttack(){ if(Time.time<next)return; next=Time.time+cooldown; Hit(basicDamage); }
  public void Skill1()=>Hit(45); public void Skill2()=>Hit(70); public void Skill3()=>Hit(55); public void Ultimate()=>Hit(180);
  void Hit(float baseDamage){ var origin=attackOrigin?attackOrigin:transform; var hits=Physics.OverlapSphere(origin.position,range,hitMask); float mult=(souls? souls.DamageMultiplier:1f)*(corruption?corruption.AbilityMultiplier:1f); foreach(var h in hits){var d=h.GetComponentInParent<Damageable>(); if(d)d.TakeDamage(baseDamage*mult);} }
 }
}

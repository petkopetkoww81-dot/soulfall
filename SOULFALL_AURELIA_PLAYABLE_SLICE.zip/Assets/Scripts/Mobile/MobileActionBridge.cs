using UnityEngine;
using Soulfall.Player;
using Soulfall.Skills;
using Soulfall.Combat;

namespace Soulfall.Mobile
{
    public class MobileActionBridge : MonoBehaviour
    {
        public ThirdPersonMobileMotor motor;
        public ClassAbilitySet abilities;
        public LockOnTargeting lockOn;

        public void MoveX(float x)
        {
            if (motor == null) return;
        }

        public void Dodge() => motor?.Dodge();
        public void SprintOn() => motor?.SetSprint(true);
        public void SprintOff() => motor?.SetSprint(false);

        public void CastPrimary() => Cast(0);
        public void CastSkill1() => Cast(1);
        public void CastSkill2() => Cast(2);
        public void CastSkill3() => Cast(3);
        public void CastUltimate() => Cast(4);

        void Cast(int slot)
        {
            if (abilities == null || lockOn == null) return;
            var target = lockOn.CurrentTarget;
            if (target != null) abilities.TryCast(slot, target);
        }
    }
}

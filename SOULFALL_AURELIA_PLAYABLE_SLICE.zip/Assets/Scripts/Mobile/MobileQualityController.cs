using UnityEngine;

namespace Soulfall.Mobile
{
    public class MobileQualityController : MonoBehaviour
    {
        [Range(30,120)] public int targetFrameRate = 60;

        void Awake()
        {
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = targetFrameRate;
        }

        public void SetPerformanceMode()
        {
            QualitySettings.SetQualityLevel(0, true);
            Application.targetFrameRate = 60;
        }

        public void SetQualityMode()
        {
            int last = Mathf.Max(0, QualitySettings.names.Length - 1);
            QualitySettings.SetQualityLevel(last, true);
            Application.targetFrameRate = 30;
        }
    }
}

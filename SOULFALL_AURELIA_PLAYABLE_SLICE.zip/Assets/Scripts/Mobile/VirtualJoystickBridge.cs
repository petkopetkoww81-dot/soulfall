using UnityEngine;
using Soulfall.Characters;
namespace Soulfall.Mobile {
 public class VirtualJoystickBridge:MonoBehaviour{
  public WarriorController player; public Vector2 value;
  public void SetHorizontal(float v){value.x=v;Push();} public void SetVertical(float v){value.y=v;Push();}
  public void ResetStick(){value=Vector2.zero;Push();} void Push(){if(player)player.SetMove(value);}
  public void Dodge(){if(player)player.Dodge();}
 }
}

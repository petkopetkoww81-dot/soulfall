using System;
using System.Threading.Tasks;
namespace Soulfall.Auth {
 public class MockAuthService : IAuthService {
  public Task<AuthUser> SignInGuest()=>Task.FromResult(new AuthUser{id=Guid.NewGuid().ToString(),displayName="Wanderer",guest=true});
  public Task<AuthUser> SignInEmail(string e,string p)=>Task.FromResult(new AuthUser{id="email_"+e,email=e,displayName=e,guest=false});
  public Task<AuthUser> RegisterEmail(string e,string p)=>SignInEmail(e,p);
  public Task<AuthUser> SignInProvider(AuthProvider provider,string token)=>Task.FromResult(new AuthUser{id=provider+"_"+Guid.NewGuid(),displayName=provider.ToString(),guest=false});
 }
}

using System;
namespace Soulfall.Auth {
  [Serializable] public class AuthUser { public string id; public string email; public string displayName; public bool guest; }
  public enum AuthProvider { Guest, Email, Apple, Google }
}

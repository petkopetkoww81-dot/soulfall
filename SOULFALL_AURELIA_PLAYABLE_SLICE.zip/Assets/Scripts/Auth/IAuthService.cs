using System.Threading.Tasks;
namespace Soulfall.Auth {
 public interface IAuthService { Task<AuthUser> SignInGuest(); Task<AuthUser> SignInEmail(string email,string password); Task<AuthUser> RegisterEmail(string email,string password); Task<AuthUser> SignInProvider(AuthProvider provider,string token); }
}

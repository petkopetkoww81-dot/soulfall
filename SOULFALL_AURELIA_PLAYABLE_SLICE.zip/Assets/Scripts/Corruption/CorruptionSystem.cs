using UnityEngine; using System; using Soulfall.Core;
namespace Soulfall.Corruption {
 public enum CorruptionStage{Normal,SoulTouched,Scarred,Transformed,Fallen}
 public class CorruptionSystem:MonoBehaviour{[Range(0,100)]public int value;public event Action<int,CorruptionStage> Changed; public CorruptionStage Stage=>value>=100?CorruptionStage.Fallen:value>=90?CorruptionStage.Transformed:value>=60?CorruptionStage.Scarred:value>=30?CorruptionStage.SoulTouched:CorruptionStage.Normal; public void Change(int v){value=Mathf.Clamp(value+v,0,100);Changed?.Invoke(value,Stage);SoulfallEvents.OnCorruptionChanged?.Invoke(value);} public float AbilityMultiplier=>Stage==CorruptionStage.Fallen?1.75f:Stage==CorruptionStage.Transformed?1.4f:Stage==CorruptionStage.Scarred?1.2f:1f;}
}

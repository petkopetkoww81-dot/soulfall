using UnityEngine;using System.Collections.Generic;
namespace Soulfall.Guilds { public class GuildSystem:MonoBehaviour{public int reputation;public List<string> unlockedBosses=new();public void UnlockBoss(string id){if(!unlockedBosses.Contains(id))unlockedBosses.Add(id);} } }

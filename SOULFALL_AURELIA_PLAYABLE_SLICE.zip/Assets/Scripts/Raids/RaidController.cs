using UnityEngine;
namespace Soulfall.Raids { public class RaidController:MonoBehaviour{public int recommendedPartySize=10;public int phases=4,currentPhase=1;public void NextPhase(){currentPhase=Mathf.Min(phases,currentPhase+1);} } }

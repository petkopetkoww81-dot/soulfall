#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using Soulfall.Core;
using Soulfall.WorldState;
using Soulfall.Souls;
using Soulfall.Corruption;
using Soulfall.Mobile;
using Soulfall.Save;

namespace Soulfall.EditorTools
{
    public static class SoulfallProjectBootstrapper
    {
        const string ScenePath = "Assets/Scenes/SOULFALL_Bootstrap.unity";

        [MenuItem("SOULFALL/Create Bootstrap Scene")]
        public static void CreateBootstrapScene()
        {
            if (!AssetDatabase.IsValidFolder("Assets/Scenes"))
                AssetDatabase.CreateFolder("Assets", "Scenes");

            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

            var root = new GameObject("SOULFALL_CORE");
            var world = root.AddComponent<WorldStateManager>();
            var souls = root.AddComponent<SoulPowerSystem>();
            var corruption = root.AddComponent<CorruptionSystem>();
            var quality = root.AddComponent<MobileQualityController>();
            var save = root.AddComponent<UnifiedSaveService>();
            var gameState = root.AddComponent<SoulfallGameState>();
            root.AddComponent<RuntimeProjectValidator>();

            gameState.worldState = world;
            gameState.souls = souls;
            gameState.corruption = corruption;

            var light = Object.FindFirstObjectByType<Light>();
            if (light != null)
            {
                light.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
                light.intensity = 1.2f;
            }

            EditorSceneManager.SaveScene(scene, ScenePath);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(ScenePath, true)
            };

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("[SOULFALL] Bootstrap scene created and added to Build Settings.");
        }
    }
}
#endif

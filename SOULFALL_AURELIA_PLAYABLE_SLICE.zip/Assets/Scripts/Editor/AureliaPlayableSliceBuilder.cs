#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;
using Soulfall.Player;
using Soulfall.Combat;
using Soulfall.Enemies;
using Soulfall.Boss;
using Soulfall.Skills;
using Soulfall.Characters;
using Soulfall.Quests;

namespace Soulfall.EditorTools
{
    public static class AureliaPlayableSliceBuilder
    {
        const string ScenePath = "Assets/Scenes/Aurelia_Playable.unity";

        [MenuItem("SOULFALL/Build Aurelia Playable Slice")]
        public static void Build()
        {
            if (!AssetDatabase.IsValidFolder("Assets/Scenes"))
                AssetDatabase.CreateFolder("Assets", "Scenes");

            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

            CreateGround("Ember Gate", new Vector3(0,0,0), new Vector3(32,1,32));
            CreateGround("Sunken Gardens", new Vector3(0,0,42), new Vector3(34,1,34));
            CreateGround("Warden Citadel", new Vector3(0,0,90), new Vector3(40,1,40));

            var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name = "Player_Warrior";
            player.tag = "Player";
            player.transform.position = new Vector3(0,1,0);

            Object.DestroyImmediate(player.GetComponent<Collider>());
            var cc = player.AddComponent<CharacterController>();
            cc.height = 2f;
            cc.radius = .4f;

            var hp = player.AddComponent<Damageable>();
            hp.MaxHealth = 500;
            hp.CurrentHealth = 500;

            var motor = player.AddComponent<ThirdPersonMobileMotor>();
            var identity = player.AddComponent<ClassIdentity>();
            identity.selectedClass = SoulfallClass.Warrior;

            var abilitySet = player.AddComponent<ClassAbilitySet>();
            var presets = player.AddComponent<ClassAbilityPresets>();
            presets.abilities = abilitySet;
            presets.Apply(SoulfallClass.Warrior);

            var cam = Camera.main;
            if (cam != null)
            {
                cam.transform.position = new Vector3(0,12,-12);
                cam.transform.rotation = Quaternion.Euler(35,0,0);
                motor.cameraTransform = cam.transform;
            }

            for (int i=0;i<5;i++)
                CreateHound(new Vector3(-6 + i*3, 1, 18), player.transform);

            var warden = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            warden.name = "Aurelia_Warden";
            warden.tag = "Enemy";
            warden.transform.position = new Vector3(0,1,92);
            warden.transform.localScale = new Vector3(2.2f,2.8f,2.2f);
            var whp = warden.AddComponent<Damageable>();
            whp.MaxHealth = 1800;
            whp.CurrentHealth = 1800;
            var wardenLogic = warden.AddComponent<AureliaWarden>();

            var arena = new GameObject("Warden_Arena");
            var arenaController = arena.AddComponent<WardenArenaController>();
            arenaController.warden = whp;

            var q = new GameObject("Quest_Ashes_At_The_Gate");
            var quest = q.AddComponent<QuestRuntime>();
            quest.questId = "ashes_at_the_gate";
            quest.objectives.Add(new QuestObjectiveState
            {
                id="kill_hounds",
                type=ObjectiveType.Kill,
                targetId="hollow_hound",
                required=5
            });
            quest.objectives.Add(new QuestObjectiveState
            {
                id="ember_shard",
                type=ObjectiveType.Collect,
                targetId="ember_shard",
                required=1
            });

            var light = Object.FindFirstObjectByType<Light>();
            if (light != null)
            {
                light.transform.rotation = Quaternion.Euler(48f, -25f, 0f);
                light.intensity = 1.1f;
            }

            EditorSceneManager.SaveScene(scene, ScenePath);
            var scenes = new[]
            {
                new EditorBuildSettingsScene("Assets/Scenes/SOULFALL_Bootstrap.unity", true),
                new EditorBuildSettingsScene(ScenePath, true)
            };
            EditorBuildSettings.scenes = scenes;
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Debug.Log("[SOULFALL] Aurelia playable slice scene generated.");
        }

        static void CreateGround(string name, Vector3 pos, Vector3 scale)
        {
            var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
            g.name = name;
            g.transform.position = pos + Vector3.down * .5f;
            g.transform.localScale = scale;
        }

        static void CreateHound(Vector3 pos, Transform player)
        {
            var h = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            h.name = "Hollow_Hound";
            h.tag = "Enemy";
            h.transform.position = pos;
            h.transform.localScale = new Vector3(.8f,.8f,1.2f);
            var hp = h.AddComponent<Damageable>();
            hp.MaxHealth = 90;
            hp.CurrentHealth = 90;
            var agent = h.AddComponent<NavMeshAgent>();
            agent.speed = 3.8f;
            var melee = h.AddComponent<EnemyMeleeController>();
            melee.target = player;
        }
    }
}
#endif

#if UNITY_EDITOR
using UnityEditor;using UnityEditor.SceneManagement;using UnityEngine;using Soulfall.Core;using Soulfall.Characters;using Soulfall.Combat;using Soulfall.Enemies;using Soulfall.Boss;using Soulfall.Souls;using Soulfall.Corruption;using Soulfall.Bounty;using Soulfall.Factions;using Soulfall.Companions;using Soulfall.Guilds;using Soulfall.Quests;
namespace Soulfall.EditorTools {
 public static class SoulfallProjectBuilder {
  [MenuItem("SOULFALL/Build Aurelia Prototype Scene")]
  public static void BuildScene(){
   var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
   var bootstrap=new GameObject("SOULFALL_BOOTSTRAP");bootstrap.AddComponent<GameBootstrap>();
   var light=new GameObject("Directional Light");var dl=light.AddComponent<Light>();dl.type=LightType.Directional;dl.intensity=1.2f;light.transform.rotation=Quaternion.Euler(50,-30,0);
   var camGO=new GameObject("Main Camera");camGO.tag="MainCamera";var cam=camGO.AddComponent<Camera>();camGO.transform.position=new Vector3(0,10,-12);camGO.transform.rotation=Quaternion.Euler(28,0,0);
   var ground=GameObject.CreatePrimitive(PrimitiveType.Plane);ground.name="Ember Gate Ground";ground.transform.localScale=new Vector3(4,1,4);
   var player=GameObject.CreatePrimitive(PrimitiveType.Capsule);player.name="Player_Warrior";player.tag="Player";player.transform.position=new Vector3(0,1,0);Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());player.AddComponent<CharacterController>();player.AddComponent<Damageable>().maxHealth=500;player.AddComponent<WarriorController>();var souls=player.AddComponent<SoulPowerSystem>();var corr=player.AddComponent<CorruptionSystem>();var bounty=player.AddComponent<BountyManager>();var factions=player.AddComponent<FactionReputation>();var comps=player.AddComponent<CompanionSystem>();var guild=player.AddComponent<GuildSystem>();var quest=player.AddComponent<AncientKingQuest>();quest.souls=souls;quest.corruption=corr;quest.companions=comps;quest.guild=guild;quest.factions=factions;
   for(int i=0;i<5;i++){var h=GameObject.CreatePrimitive(PrimitiveType.Capsule);h.name="Hollow Hound "+(i+1);h.transform.position=new Vector3(-6+i*3,1,8);h.AddComponent<Damageable>().maxHealth=90;h.AddComponent<HollowHound>();}
   var boss=GameObject.CreatePrimitive(PrimitiveType.Cube);boss.name="Aurelia Warden";boss.transform.position=new Vector3(0,2,18);boss.transform.localScale=new Vector3(3,4,2);var dh=boss.AddComponent<Damageable>();dh.maxHealth=1800;boss.AddComponent<AureliaWarden>();
   EditorSceneManager.SaveScene(scene,"Assets/Scenes/Aurelia_Prototype.unity");
   EditorUtility.DisplayDialog("SOULFALL","Aurelia_Prototype scene created. Add UI/Input bindings and art assets next.","OK");
  }
 }
}
#endif

using UnityEngine; using System.Collections.Generic;
namespace Soulfall.Equipment { public class EquipmentSystem:MonoBehaviour{public List<string> equipped=new(); public void Equip(string id){if(!equipped.Contains(id))equipped.Add(id);} } }

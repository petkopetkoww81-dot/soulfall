using UnityEngine; using System; using System.Collections.Generic; using Soulfall.Core;
namespace Soulfall.WorldState {
 [Serializable] public class WorldFlag{public string id; public string value;}
 public class WorldStateManager:MonoBehaviour{
  public static WorldStateManager Instance{get;private set;} public List<WorldFlag> flags=new();
  void Awake(){if(Instance!=null&&Instance!=this){Destroy(gameObject);return;}Instance=this;DontDestroyOnLoad(gameObject);}
  public void Set(string id,string value="true"){var f=flags.Find(x=>x.id==id);if(f==null){f=new WorldFlag{id=id};flags.Add(f);}f.value=value;SoulfallEvents.OnWorldFlagChanged?.Invoke(id,value);} public bool Has(string id,string value="true"){var f=flags.Find(x=>x.id==id);return f!=null&&f.value==value;}
 }
}

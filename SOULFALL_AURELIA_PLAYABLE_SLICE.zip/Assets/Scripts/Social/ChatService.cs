using UnityEngine;using System;
namespace Soulfall.Social { public class ChatService:MonoBehaviour{public event Action<string,string> Message;public void SendLocal(string author,string message){if(!string.IsNullOrWhiteSpace(message))Message?.Invoke(author,message);} } }

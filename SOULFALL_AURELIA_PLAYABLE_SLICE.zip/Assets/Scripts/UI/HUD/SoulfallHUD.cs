using UnityEngine;
using UnityEngine.UI;
using Soulfall.Combat;
using Soulfall.Corruption;
using Soulfall.Souls;
using Soulfall.Progression;

namespace Soulfall.UI
{
    public class SoulfallHUD : MonoBehaviour
    {
        public Slider healthBar;
        public Slider corruptionBar;
        public Slider soulPowerBar;
        public Text levelText;
        public Text corruptionText;

        public Damageable playerHealth;
        public CorruptionSystem corruption;
        public SoulPowerSystem souls;
        public LevelSystem level;

        void Update()
        {
            if (playerHealth != null && healthBar != null)
            {
                healthBar.maxValue = Mathf.Max(1f, playerHealth.MaxHealth);
                healthBar.value = playerHealth.CurrentHealth;
            }

            if (corruption != null)
            {
                if (corruptionBar) corruptionBar.value = corruption.value;
                if (corruptionText) corruptionText.text = $"Corruption {corruption.value}%";
            }

            if (souls != null && soulPowerBar != null)
            {
                soulPowerBar.maxValue = 500;
                soulPowerBar.value = souls.soulPower;
            }

            if (level != null && levelText != null)
                levelText.text = $"Lv. {level.Level}";
        }
    }
}

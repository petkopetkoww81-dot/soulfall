using UnityEngine;
using UnityEngine.UI;
using Soulfall.Quests;

namespace Soulfall.UI
{
    public class QuestTrackerHUD : MonoBehaviour
    {
        public QuestRuntime quest;
        public Text titleText;
        public Text objectiveText;

        void Update()
        {
            if (quest == null || titleText == null || objectiveText == null) return;

            titleText.text = quest.questId;
            if (quest.completed)
            {
                objectiveText.text = "Completed";
                return;
            }

            string text = "";
            foreach (var o in quest.objectives)
                text += $"{o.targetId}: {o.current}/{o.required}\n";

            objectiveText.text = text;
        }
    }
}

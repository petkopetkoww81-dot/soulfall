using UnityEngine;using Soulfall.Quests;
namespace Soulfall.UI { public class QuestChoicePanel:MonoBehaviour{public AncientKingQuest quest;public void Release()=>quest?.Release();public void Consume()=>quest?.Consume();public void Resurrect()=>quest?.Resurrect();public void Guild()=>quest?.GiveToGuild();} }

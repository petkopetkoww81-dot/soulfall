using System;
namespace Soulfall.Characters {
 public class CharacterCreationService {
  public CharacterProfile Create(string name,string classId,int preset){return new CharacterProfile{id=Guid.NewGuid().ToString(),name=name,classId=classId,appearancePreset=preset};}
 }
}

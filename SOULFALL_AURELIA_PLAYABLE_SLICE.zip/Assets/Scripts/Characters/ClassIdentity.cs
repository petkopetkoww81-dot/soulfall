using UnityEngine;

namespace Soulfall.Characters
{
    public enum SoulfallClass { Warrior, Assassin, Mage, Ranger, Necromancer }

    public class ClassIdentity : MonoBehaviour
    {
        public SoulfallClass selectedClass = SoulfallClass.Warrior;
        public string characterName = "Fallen";
        public int appearancePreset;
    }
}

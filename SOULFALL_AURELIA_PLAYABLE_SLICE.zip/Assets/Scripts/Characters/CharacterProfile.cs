using System;
namespace Soulfall.Characters {
 [Serializable] public class CharacterProfile { public string id; public string name; public string classId; public int appearancePreset; public int level=1; public int xp; public int gold; public int crystals; }
}

using UnityEngine;
namespace Soulfall.Characters {
 [RequireComponent(typeof(CharacterController))]
 public class WarriorController:MonoBehaviour{
  public float moveSpeed=5.6f,sprintSpeed=7.5f,gravity=-24f,dodgeSpeed=18f,dodgeDuration=.2f,dodgeCooldown=.75f;
  CharacterController cc; Vector3 velocity; Vector2 moveInput; bool sprint; float dodgeUntil,nextDodge; Vector3 dodgeDir;
  void Awake(){cc=GetComponent<CharacterController>();}
  public void SetMove(Vector2 v)=>moveInput=Vector2.ClampMagnitude(v,1); public void SetSprint(bool v)=>sprint=v;
  public void Dodge(){if(Time.time<nextDodge)return; nextDodge=Time.time+dodgeCooldown; dodgeUntil=Time.time+dodgeDuration; dodgeDir=transform.forward;}
  void Update(){
   var cam=Camera.main; Vector3 f=cam?Vector3.Scale(cam.transform.forward,new Vector3(1,0,1)).normalized:Vector3.forward; Vector3 r=cam?cam.transform.right:Vector3.right;
   Vector3 dir=(f*moveInput.y+r*moveInput.x); if(dir.sqrMagnitude>.01f)transform.forward=Vector3.Slerp(transform.forward,dir.normalized,15*Time.deltaTime);
   float speed=sprint?sprintSpeed:moveSpeed; if(Time.time<dodgeUntil){dir=dodgeDir; speed=dodgeSpeed;}
   if(cc.isGrounded && velocity.y<0)velocity.y=-2; velocity.y+=gravity*Time.deltaTime;
   cc.Move((dir.normalized*speed+velocity)*Time.deltaTime);
  }
 }
}

using UnityEngine;
using Soulfall.Combat;
using Soulfall.WorldState;
namespace Soulfall.Boss {
 [RequireComponent(typeof(Damageable))]
 public class AureliaWarden:MonoBehaviour{
  public float baseDamage=28; Damageable hp; int phase=1;
  void Awake(){hp=GetComponent<Damageable>();hp.maxHealth=1800;hp.health=1800;hp.Damaged+=_=>Refresh();hp.Died+=OnDeath;}
  void Refresh(){float p=hp.health/hp.maxHealth;phase=p<=.30f?3:p<=.65f?2:1;}
  public float Damage=>baseDamage*(phase==3?1.75f:phase==2?1.35f:1f);
  void OnDeath(){WorldStateManager.Instance?.Set("aurelia_warden_defeated");WorldStateManager.Instance?.Set("soulblade_of_the_fallen_unlocked");}
 }
}

using UnityEngine;
using Soulfall.Combat;
using Soulfall.WorldState;

namespace Soulfall.Boss
{
    public class WardenArenaController : MonoBehaviour
    {
        public GameObject entranceBarrier;
        public GameObject exitBarrier;
        public Damageable warden;
        public bool started;
        public bool completed;

        public void BeginEncounter()
        {
            if (started || completed) return;
            started = true;
            if (entranceBarrier) entranceBarrier.SetActive(true);
            if (exitBarrier) exitBarrier.SetActive(true);
        }

        void Update()
        {
            if (!started || completed || warden == null) return;
            if (warden.CurrentHealth > 0) return;

            completed = true;
            if (exitBarrier) exitBarrier.SetActive(false);
            WorldStateManager.Instance?.Set("aurelia_warden_defeated");
        }
    }
}

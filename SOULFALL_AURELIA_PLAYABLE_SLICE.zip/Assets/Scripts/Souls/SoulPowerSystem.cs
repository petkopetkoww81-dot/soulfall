using UnityEngine; using System;
namespace Soulfall.Souls { public class SoulPowerSystem:MonoBehaviour{public int absorbedSouls,soulPower;public event Action Changed; public void AbsorbSoul(int power){absorbedSouls++;soulPower+=Mathf.Max(1,power);Changed?.Invoke();} public float DamageMultiplier=>1f+Mathf.Min(soulPower,500)*.0015f;} }

using UnityEngine;
using Soulfall.WorldState;

namespace Soulfall.World
{
    public class AureliaRegionGate : MonoBehaviour
    {
        public string requiredFlag;
        public GameObject blocker;
        public GameObject unlockedVisual;

        void Start() => Refresh();

        public void Refresh()
        {
            bool unlocked = string.IsNullOrEmpty(requiredFlag) ||
                            (WorldStateManager.Instance != null &&
                             WorldStateManager.Instance.Has(requiredFlag));

            if (blocker) blocker.SetActive(!unlocked);
            if (unlockedVisual) unlockedVisual.SetActive(unlocked);
        }
    }
}

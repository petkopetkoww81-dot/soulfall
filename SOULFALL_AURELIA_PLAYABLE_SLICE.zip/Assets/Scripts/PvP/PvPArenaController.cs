using UnityEngine;
namespace Soulfall.PvP { public class PvPArenaController:MonoBehaviour{public int scoreToWin=20;public int teamA,teamB;public bool Finished=>teamA>=scoreToWin||teamB>=scoreToWin;} }

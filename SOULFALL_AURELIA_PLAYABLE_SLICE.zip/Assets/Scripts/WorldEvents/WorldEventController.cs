using UnityEngine;
namespace Soulfall.WorldEvents { public class WorldEventController:MonoBehaviour{public string eventId="soulstorm";public float duration=1200;public float remaining;public bool active;public void StartEvent(){active=true;remaining=duration;}void Update(){if(!active)return;remaining-=Time.deltaTime;if(remaining<=0){remaining=0;active=false;}}} }

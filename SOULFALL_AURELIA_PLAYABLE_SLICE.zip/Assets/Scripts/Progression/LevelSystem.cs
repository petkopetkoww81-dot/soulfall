using UnityEngine;
using Soulfall.Core;
namespace Soulfall.Progression {
 public class LevelSystem:MonoBehaviour{public int level=1,xp; public int Required=>100+level*75; public void AddXp(int v){xp+=Mathf.Max(0,v);while(xp>=Required){xp-=Required;level++;SoulfallEvents.OnPlayerLevelChanged?.Invoke(level);}}}
}

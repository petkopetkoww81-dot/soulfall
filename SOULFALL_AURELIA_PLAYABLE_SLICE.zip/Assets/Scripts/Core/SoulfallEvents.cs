using System;
namespace Soulfall.Core {
  public static class SoulfallEvents {
    public static Action<int> OnPlayerLevelChanged;
    public static Action<string> OnItemUnlocked;
    public static Action<string,string> OnWorldFlagChanged;
    public static Action<int> OnCorruptionChanged;
  }
}

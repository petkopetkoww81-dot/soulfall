using UnityEngine;
using Soulfall.WorldState;
using Soulfall.Save;
namespace Soulfall.Core {
  public class GameBootstrap : MonoBehaviour {
    public static GameBootstrap Instance { get; private set; }
    void Awake(){
      if(Instance!=null && Instance!=this){Destroy(gameObject);return;}
      Instance=this; DontDestroyOnLoad(gameObject);
      Ensure<WorldStateManager>("WorldState"); Ensure<LocalSaveService>("SaveService");
    }
    void Ensure<T>(string name) where T:Component {
      if(FindFirstObjectByType<T>()!=null) return;
      var go=new GameObject(name); go.transform.SetParent(transform); go.AddComponent<T>();
    }
  }
}

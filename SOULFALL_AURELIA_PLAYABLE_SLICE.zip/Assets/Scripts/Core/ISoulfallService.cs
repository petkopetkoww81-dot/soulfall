namespace Soulfall.Core
{
    public interface ISoulfallService
    {
        bool IsReady { get; }
        void Initialize();
    }
}

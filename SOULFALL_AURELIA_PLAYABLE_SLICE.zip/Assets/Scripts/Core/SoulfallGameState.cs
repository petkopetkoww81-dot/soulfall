using UnityEngine;
using Soulfall.WorldState;
using Soulfall.Souls;
using Soulfall.Corruption;
using Soulfall.Progression;
using Soulfall.Inventory;
using Soulfall.Factions;
using Soulfall.Companions;
using Soulfall.Guilds;

namespace Soulfall.Core
{
    public class SoulfallGameState : MonoBehaviour
    {
        public static SoulfallGameState Instance { get; private set; }

        public WorldStateManager worldState;
        public SoulPowerSystem souls;
        public CorruptionSystem corruption;
        public LevelSystem level;
        public InventorySystem inventory;
        public FactionReputation factions;
        public CompanionSystem companions;
        public GuildSystem guild;

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        public bool Ready =>
            worldState != null &&
            souls != null &&
            corruption != null &&
            level != null;
    }
}

using UnityEngine;

namespace Soulfall.Core
{
    public class RuntimeProjectValidator : MonoBehaviour
    {
        public SoulfallGameState gameState;

        void Start()
        {
            if (gameState == null) gameState = SoulfallGameState.Instance;

            if (gameState == null)
                Debug.LogError("[SOULFALL] SoulfallGameState is missing.");
            else if (!gameState.Ready)
                Debug.LogWarning("[SOULFALL] Persistent systems are not fully assigned.");
            else
                Debug.Log("[SOULFALL] Core runtime validation passed.");
        }
    }
}

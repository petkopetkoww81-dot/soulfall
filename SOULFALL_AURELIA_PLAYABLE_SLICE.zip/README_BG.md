# SOULFALL — MASTER UNITY PROJECT

Това е единният основен проект на SOULFALL. Не е разделен на M1/M2/M3 модули.

## Какво вече е интегрирано
- account/auth abstractions: Apple, Google, email, guest
- character creation и 5 класа
- Warrior combat controller
- enemies и Aurelia Warden boss
- quests, branching choices и persistent world-state
- inventory, equipment, rarity, XP/levels
- Souls, Soul Power, Corruption, Fallen Form
- bounty, factions, companions, guild unlocks
- PvP/dungeons/raids/world events scaffolds
- save/profile/backend abstractions
- mobile input bridge
- Unity Editor generator за базови сцени

## Важно
Това е compile-oriented source project, но не е готов AAA продукт. Липсват финалните 3D модели, ригове, анимации, VFX, аудио, cinematic content, production backend, live multiplayer инфраструктура, App Store signing и финален iOS build.

## Първа playable loop цел
Login → Character Creation → Warrior → Ember Gate → Hollow Hounds → Ancient King choice → Soul/Corruption consequences → Aurelia Warden → loot/unlocks.

# SOULFALL — Aurelia playable vertical slice

Тази версия добавя реален gameplay слой към единния проект.

## Какво е добавено
- third-person mobile CharacterController
- sprint и dodge
- пет class ability preset-а вече могат да нанасят damage
- combat target abstraction
- melee enemy controller
- encounter data
- loot tables и loot grant hooks
- Warden arena state
- region gates
- HUD hooks за health/corruption/soul power/level
- quest tracker HUD
- Aurelia scene builder
- Aurelia locations + encounter + loot data

## Генериране на сцената
В Unity:
SOULFALL -> Build Aurelia Playable Slice

Създава:
Assets/Scenes/Aurelia_Playable.unity

Съдържа prototype геометрия за Ember Gate, Sunken Gardens и Warden Citadel,
Warrior player, 5 Hollow Hounds, Aurelia Warden и quest object.

## Ограничение
Това все още използва primitive prototype geometry. Няма финални 3D assets,
анимации и VFX. Целта на този слой е реален gameplay flow и интеграция.

# SOULFALL — Master Game Design

## Pillars
1. Dark-fantasy action RPG с mobile-first controls.
2. Реални последствия от решенията: world flags, faction reactions, companions, bosses, class paths.
3. Build identity: Warrior, Assassin, Mage, Ranger, Necromancer.
4. PvE-first progression; PvP/bounty е consequence layer, не задължителен pay-to-win loop.
5. Premium crystals са за cosmetics/convenience; реалните iOS покупки трябва да използват App Store IAP.

## Necromancer soul system
Ancient King quest има 4 последствия:
- освободи → Holy Necromancy
- погълни → Dark Necromancy + Soul Power + Corruption
- възкреси → Ancient King companion
- предай на guild → guild boss + reputation

## Corruption
0–29 Normal
30–59 Soul-Touched: glowing eyes
60–89 Scarred: demonic markings
90–99 Transformed: armor/abilities mutate, bounty active
100 Fallen Form: maximum corrupted power, hunters can track the player

Силата има цена: hostile factions, holy content locks, bounty, alternate endings, NPC reactions.

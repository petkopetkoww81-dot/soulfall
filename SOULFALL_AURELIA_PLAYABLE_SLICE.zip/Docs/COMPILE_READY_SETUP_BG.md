# SOULFALL — Compile-ready Unity structure

Проектът вече има стандартните Unity директории:
- Assets
- Packages
- ProjectSettings

Добавени са:
- package manifest
- package lock
- runtime asmdef
- editor asmdef
- Unity 6 project version
- bootstrap scene generator
- basic EditMode tests
- explicit core/backend models

## Първо отваряне в Unity
Unity Package Manager ще резолвира пакетите.
След това използвай меню:
SOULFALL -> Create Bootstrap Scene

То ще създаде:
Assets/Scenes/SOULFALL_Bootstrap.unity
и ще го добави в Build Settings.

## Важно
Това е compile-oriented project structure. Тук не е извършен реален Unity Editor compile,
защото в тази среда няма Unity Editor. Затова не твърдим, че проектът е минал
Unity compilation до момента.

# Content Roadmap

Regions: Aurelia (1–20), Darknor (20–35), Velmire (35–50), Zarith (50–65), Keldor (65–80), Nerath (80–100).

Aurelia vertical slice content target:
- Ember Gate hub/field
- Hollow Hound
- Aurelia Warden
- Ancient King soul quest
- Soulforged Blade
- Soulblade of the Fallen
- Warden Reborn skin
- Sunken Gardens unlock

Art bottleneck:
- 5 player class models + armor sets
- enemy roster
- bosses
- environment kits
- animation library
- combat VFX
- UI art
- audio/music/voice
